@extends('modele')

@section('contents')
    <p>Page d' accueil</p>
@endsection
