<?php $__env->startSection('title','Connexion'); ?>

<?php $__env->startSection('contenu'); ?>
    <style>
        label{
            color: white;
        }
        p,h3,form{
            color: white;
        }
    </style>
    <a href="<?php echo e(route('home')); ?>"><button style="background-color:white;color: dark;border-color:white;">Page principale</button></a>
    <h3>Connexion</h3>
    <div id="form">
    <form method="post">
        <?php echo csrf_field(); ?>
        Login: <input type="text" name="login" value="<?php echo e(old('login')); ?>">
        Mot de passe: <input type="password" name="mdp">
        <button style="background-color:royalblue;color: white;border-color: royalblue;" type="submit" value="Envoyer">Se connecter</button>
    </form>
    <hr>
    <p>Vous n'avez pas de compte ? <a href="<?php echo e(route('register')); ?>"><button style="background-color:lightseagreen;color: white;border-color: lightseagreen;">Créer un compte</button></a></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/auth/login.blade.php ENDPATH**/ ?>