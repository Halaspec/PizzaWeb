<?php $__env->startSection('title','Créer un utilisateur'); ?>

<?php $__env->startSection('contenu'); ?>
    <style>
        label,h3{
            color: white;
        }
    </style>
    <a href="<?php echo e(route('home')); ?>"><button style="background-color:white;color: dark;border-color:white;">Retour à l'accueil</button></a><br>
    <br><a href="<?php echo e(route('creerA')); ?>"><button style="background-color:darkslategrey;color: white;border-color:darkslategrey;">Admin</button></a>
    <a href="<?php echo e(route('creerK')); ?>"><button style="background-color:darkslategrey;color: white;border-color:darkslategrey;">Cook</button></a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/admin/creer_utilisateur.blade.php ENDPATH**/ ?>