<?php $__env->startSection('title','Créer un admin'); ?>

<?php $__env->startSection('contenu'); ?>
    <style>
        label,h3{
            color: white;
        }
    </style>
    <a href="<?php echo e(route('home')); ?>"><button style="background-color:white;color: dark;border-color:white;">Retour à l'accueil</button></a>
    <h3>Création des Admin</h3>
    <form action="<?php echo e(route('creerA')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="nom">Nom</label><br>
        <input type="text" name="nom" value="<?php echo e(old('nom')); ?>"><br>
        <label for="prenom">Prenom</label><br>
        <input type="text" name="prenom" value="<?php echo e(old('prenom')); ?>"><br>
        <label for="login">Login</label><br>
        <input type="text" name="login" value="<?php echo e(old('login')); ?>"><br>
        <label for="mdp">Mot de passe</label><br>
        <input type="password" name="mdp"><br>
        <label for="mdp_confirmation">Confirmation mot de passe</label><br>
        <input type="password" name="mdp_confirmation"><br>
        <br>
        <a><button style="background-color:lightseagreen;color: white;border-color: lightseagreen;"type="submit" value="Envoyer">Créer</button></a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/admin/creer_admin.blade.php ENDPATH**/ ?>