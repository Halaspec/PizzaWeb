<?php $__env->startSection('title','Suppression des pizzas'); ?>

<?php $__env->startSection('contenu'); ?>
    <p>Voulez-vous supprimer la Pizza <?php echo e($pizza->nom); ?></p>
    <form action="<?php echo e(route('suppressionP',['id'=>$pizza->id])); ?>" method="post">
    <?php echo csrf_field(); ?>
        <input type="submit" value="Supprimer">
    </form>
    <button style="padding-left: 15px;margin-top: 10px;"><a href="<?php echo e(route('listeP')); ?>" type="submit" value="Annuler" style="color: black ;text-decoration: none;width: 70px">Annuler</a></button>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/pizza/supp_pizza.blade.php ENDPATH**/ ?>