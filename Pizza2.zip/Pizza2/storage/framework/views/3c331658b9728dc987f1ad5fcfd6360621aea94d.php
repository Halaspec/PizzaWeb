<?php $__env->startSection('title','Modification des pizzas'); ?>
<style>
    form{
        color: white;
    }
</style>

<?php $__env->startSection('contenu'); ?>
    <p>Voulez-vous modifier la pizza <?php echo e($pizza->nom); ?></p>
    <form action="<?php echo e(route('modification',['id'=>$pizza->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        Nom:
        <input type="text" name="nom" value="<?php echo e($pizza->nom); ?>">
        Description:
        <input type="text" name="description" value="<?php echo e($pizza->description); ?>">
        Prix:
        <input type="decimal" name="prix" value="<?php echo e($pizza->prix); ?>">

        <input type="submit" name="Modifier" value="Modifier">

        <input type="submit" name="Annuler" value="Annuler">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/pizza/modif_pizza.blade.php ENDPATH**/ ?>