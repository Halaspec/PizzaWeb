<?php $__env->startSection('title','Administrateur'); ?>
<?php $__env->startSection('contenu'); ?>
    <p>Page d'acceuil admin</p>
    <a href="<?php echo e(route('ajouterP')); ?>">Ajouter une pizza</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/admin/admin_home.blade.php ENDPATH**/ ?>