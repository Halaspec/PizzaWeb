<?php $__env->startSection('title','Les utilisateurs cook'); ?>
       <style>
            h3{
                color: white;
            }
       </style>

<?php $__env->startSection('contenu'); ?>
    <h3>Liste des utilisateurs Cook</h3>
    <table border="1">
        <th>Nom</th>
        <th>Prenom</th>
        <th>Login</th>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user ->type!="admin" && $user ->type!="user"): ?>
            <tr>
                <td><?php echo e($user->nom); ?></td>
                <td><?php echo e($user->prenom); ?></td>
                <td><?php echo e($user->login); ?></td>
                <td><a href="<?php echo e(route('modifMdpCook',['id'=>$user->id])); ?>"><button>Modifier le mot de passe</button></a></td>
            </tr>
                <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/user/list_cook.blade.php ENDPATH**/ ?>