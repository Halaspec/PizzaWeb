<?php $__env->startSection('title','Ajout des pizzas'); ?>

<?php $__env->startSection('contenu'); ?>

    <style>
        h3,form{
            color: white;
        }
    </style>
    <a href="<?php echo e(route('home')); ?>"><button style="background-color:white;color: dark;border-color:white;">Retour à l'accueil</button></a>
    <h3>Création des pizzas</h3>
    <form action="<?php echo e(route('ajouterP')); ?>" method="post">
        <?php echo csrf_field(); ?>
        Nom <br>
        <input type="text" name="nom"><br>
        Description <br>
        <input type="text" name="description"><br>
        Prix <br>
        <input type="decimal" name="prix">

        <button style="background-color:darkslategrey;color: white;" type="submit" value="Envoyer" >Créer</button>
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/pizza/ajout_pizza.blade.php ENDPATH**/ ?>