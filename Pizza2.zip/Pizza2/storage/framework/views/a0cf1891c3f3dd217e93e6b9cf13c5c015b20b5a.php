<?php $__env->startSection('title','Liste des Pizzas'); ?>

<?php $__env->startSection('contenu'); ?>
        <?php $__currentLoopData = $pizza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul>
                <br>
                <b>Nom:</b> <?php echo e($p->nom); ?><br>
                <b>Description:</b> <?php echo e($p->description); ?><br>
                <b>Prix:</b> <?php echo e($p->prix); ?> €<br>
                <a href="<?php echo e(route('supprimerP',['id'=>$p->id])); ?>">Supprimer</a>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br>
    <?php echo e($pizza->links()); ?><br>
    <a href="<?php echo e(route('ajouterP')); ?>">Ajouter une pizza</a>
    <hr>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/Pizza/liste_pizza.blade.php ENDPATH**/ ?>