<?php $__env->startSection('title','Mon panier'); ?>

<?php $__env->startSection('contenu'); ?>
    <style>
        h3{
            color: white;
        }
    </style>
    <a href="<?php echo e(route('home')); ?>"><button style="background-color:white;color: dark;border-color:white;">Retour à l'accueil</button></a>
    <h3>Mon panier</h3>

    <?php $__currentLoopData = $panier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p> <?php echo e($produit['nom']); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/pizza/panier.blade.php ENDPATH**/ ?>