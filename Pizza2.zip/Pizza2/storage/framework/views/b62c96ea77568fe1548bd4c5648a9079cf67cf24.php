<?php $__env->startSection('title','Liste des Utilisateurs'); ?>

<?php $__env->startSection('contenu'); ?>
    <style>
        h3{
            color: white;
        }
    </style>
    <a href="<?php echo e(route('home')); ?>"><button style="background-color:white;color: dark;border-color:white;">Retour à l'accueil</button></a>
    <h3>Liste des utilisateurs</h3>
    <table border="1">
        <th>Id</th>
        <th>Nom</th>
        <th>Penom</th>
        <th>Login</th>
        <th>Type</th>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->nom); ?></td>
            <td><?php echo e($user->prenom); ?></td>
            <td><?php echo e($user->login); ?></td>
            <td><?php echo e($user->type); ?></td>
            <td><a href="<?php echo e(route('supprimU',['id'=>$user->id])); ?>"><button>Supprimer</button></a></td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/user/user_liste.blade.php ENDPATH**/ ?>