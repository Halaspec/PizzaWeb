<?php
$total=0;
$qte =0;
$cp = 0;
?>
<?php $__env->startSection('title','Liste des Pizzas'); ?>

<?php $__env->startSection('contenu'); ?>
    <style>
        h3{
            color: white;

        }
        button{
            background-color:white;
            color: dark;
            border-color: white;
        }

        .imgPizza{
            background: url("https://images5.alphacoders.com/369/369786.jpg");
            background-size: contain;
            background-repeat: no-repeat;
        }
    </style>
    <?php if(Auth::user()->IsAdmin()): ?>
        <a href="<?php echo e(route('home')); ?>"><button style="background-color:white;color: dark;border-color:white;">Retour à l'accueil</button></a>
        <a href="<?php echo e(route('ajouterP')); ?>"><button style="background-color:white;color: dark;border-color:white;">Créer une Pizza</button></a>
        <h3>Liste des Pizzas</h3>
    <?php else: ?>
        <a href="<?php echo e(route('home')); ?>"><button style="background-color:white;color: dark;border-color:white;">Retour à l'accueil</button></a>
        <h3>Liste des Pizzas</h3>
    <?php endif; ?>
        <table>
        <tr>
            <td>Nom</td>
            <td>Description</td>
            <td>Prix</td>
            <td >Image </td>
        </tr>
        <?php $__currentLoopData = $pizza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p['nom']); ?></td>
                <td><?php echo e($p['description']); ?></td>
                <td><?php echo e($p['prix']); ?></td>
                <td class="imgPizza" ></td>
                <?php if(\Auth::user()->isAdmin()): ?>
                    <td><a href="<?php echo e(route('supprimerP',[$p['id']])); ?>"><button>Supprimer</button></a></td>
                    <td><a href="<?php echo e(route('modifierP',[$p['id']])); ?>"><button>Modifier</button></a></td>
                   
                <?php endif; ?>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
    <br><?php echo e($pizza->links()); ?><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/pizza/liste_pizza.blade.php ENDPATH**/ ?>