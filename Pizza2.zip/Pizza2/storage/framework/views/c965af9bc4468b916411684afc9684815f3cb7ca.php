<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title','Pizza'); ?></title>

    <style>

    .error{
    background: red;
    }
    .etat{
    background:lightsteelblue;
    }
    .vertical-menu {
        width: 200px;
    }

    .vertical-menu a {
        background-color: #eee;
        color: black;
        display: block;
        padding: 12px;
        text-decoration: none;
    }

    .vertical-menu a:hover {
        background-color: #ccc;
    }

    .vertical-menu a.active {
        background-color: #04AA6D;
        color: white;
    }
    table,
    th,
    td
    {

        background-color: darkgrey;
        padding: 8px;
        border: 0.5px solid black;
        border-collapse: collapse;
    }
    body{
        background-color:lightsteelblue;
        background-image: url("https://cdn.pixabay.com/photo/2020/03/21/02/26/pizza-4952509_1280.jpg");
    }
    p,h1{
        color: white;
    }
    h1{
        font-family: "Times New Roman";
        font-style: italic;
    }


    </style>

</head>
<body>
<?php $__env->startSection('contenu'); ?>
    <?php if(auth()->guard()->guest()): ?>
        <h1>Bienvenue sur La Pizzeria</h1>
        <div class="vertical-menu">
        <a href="<?php echo e(route('login')); ?>">Connexion</a>
            <hr>
        <a href="<?php echo e(route('register')); ?>">Inscription</a>
        </div>
    <?php endif; ?>
    <?php if(auth()->guard()->check()): ?>
        <h1>Bienvenue sur La Pizzeria</h1>
        <?php if(Auth::user()->IsAdmin()): ?>
            <div class="vertical-menu">
                <p>Bonjour <?php echo e(Auth::user()->login); ?></p>
                <a href="<?php echo e(route('listeP')); ?>">Les Pizzas</a>
                <a href="<?php echo e(route('ajouterP')); ?>">Créer une Pizza</a>
                <a href="<?php echo e(route('listeU')); ?>">Les Utilisateurs</a>
                <a href="<?php echo e(route('listeC')); ?>">Les Utilisateurs Cook</a>
                <a href="<?php echo e(route('creerU')); ?>">Créer un Utilisateur</a>
                <hr>
                <a style="background-color: #4a5568;" href="<?php echo e(route('modifMdp')); ?>">Changer mon mot de passe</a>
                <a style="background-color: #4a5568;" href="<?php echo e(route('logout')); ?>">Deconnexion</a>
            </div>
        <?php elseif(Auth::user()->isUser()): ?>
            <div class="vertical-menu">
                <p>Bonjour <?php echo e(Auth::user()->login); ?></p>
                <a href="<?php echo e(route('listeP')); ?>">Nos Pizzas</a>
                <hr>
                <a style="background-color: #4a5568;" href="<?php echo e(route('modifMdp')); ?>">Changer mon mot de passe</a>
                <a style="background-color: #4a5568;" href="<?php echo e(route('logout')); ?>">Deconnexion</a>
            </div>
        <?php else: ?>
            <div class="vertical-menu">
                <p>Bonjour <?php echo e(Auth::user()->login); ?></p>
                <a>Liste des commandes</a>
                <hr>
                <a style="background-color: #4a5568;" href="<?php echo e(route('modifMdp')); ?>">Changer mon mot de passe</a>
                <a style="background-color: #4a5568;" href="<?php echo e(route('logout')); ?>">Deconnexion</a>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php echo $__env->yieldSection(); ?>
<?php if($errors->any()): ?>
    <div class="error">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session()->has('etat')): ?>
    <p class="etat"><?php echo e(session()->get('etat')); ?></p>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/modele.blade.php ENDPATH**/ ?>