<?php $__env->startSection('title','Modifier le mot de passe de cook'); ?>
    <style>
           h3,form{
               color: white;
           }
    </style>
<?php $__env->startSection('contenu'); ?>
    <a href="<?php echo e(route('home')); ?>"><button style="background-color:white;color: dark;border-color:white;">Retour à l'accueil</button></a><br>
    <h3>Changement de mot de passe</h3>
    <div id="form">
        <form action="<?php echo e(route('modifierMdpCook')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value=<?php echo e($id); ?>>
            Nouveau Mot de passe <br><input type="password" name="mdp"> <br>
            Confirmation de mot de passe <br> <input type="password" name="mdp_confirmation">
            <button style="background-color:royalblue;color: white;border-color: royalblue;" type="submit" value="Envoyer">Modifier le mot de passe</button>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizza2\resources\views/admin/mdp_cook.blade.php ENDPATH**/ ?>